var w = 800,h = 600;
var player, keyboard, diamond, diamonds, coin, coins,bombs, bomb, gameOverText,upbtn,rightbtn,leftbtn,tali,killcoin,stateText;
var score = 0;
var scoreText;
var highscore;
var highscoreText;
var tali;
var platform;
var coin;
var a = 0;
var gameOverText;
var getScore;
var saveScore;

var game = new Phaser.Game( w, h, Phaser.CANVAS, '');

game.state.add("bootGame", bootGame);
game.state.add("preloadGame", preloadGame);
game.state.add("menuGame", menuGame);
game.state.add("playGame", playGame);
game.state.add("winGame", playGame);
game.state.add("loseGame", loseGame);

game.state.start("bootGame");

