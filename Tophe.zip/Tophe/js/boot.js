
bootGame = {

		create:function(){
				game.physics.startSystem(Phaser.Physics.ARCADE);
				
				game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
        		game.scale.forceLascape = true;
        		game.scale.pageAlignHorizontally = true;
        game.scale.pageAlignVertically = true;
        game.world.setBounds(0,0,800,600);
				game.state.start("preloadGame");
				keyboard = game.input.keyboard.createCursorKeys();
		},
		update: function () {
        game.scale.pageAlignVertically = true;
        game.scale.pageAlignHorizontally = true;
        game.scale.setShowAll();
        game.scale.refresh();
    }
}

preloadGame = {
	preload: function(){

	game.load.image('sky','img/sky.png');
	game.load.image('bg','img/hello.png');
	game.load.image('PrevBtn','img/back.png');
	game.load.image('play','img/PLAY.png');
	game.load.image('about','img/aboutt.png');
	game.load.image('AboutBtn','img/ABOUT.png');
	game.load.image('image3','img/bomb.png');
	game.load.image('tali1','img/tali1.png');
	game.load.image('home','img/background.png');
	game.load.spritesheet('ako','img/ako.png',57,59);
	game.load.spritesheet('pauseButton','img/Pause.png',29,29);
	game.load.spritesheet('JumpButton','img/JumpBtn.png',62,64);
	game.load.spritesheet('LeftButton','img/LeftBtn.png',62,64);
	game.load.spritesheet('RightButton','img/RightBtn.png',62,64);
	game.load.image('restart', 'img/restart.png');
	game.load.spritesheet('img','img/tao2.png',627,674);
	game.load.spritesheet('tao1','img/tao1.png',151,481);
	game.load.image('platform','img/platform.png');
	game.load.image('coin','img/coin.png',628,678);
	game.load.audio('kansyon','audio/sound.mp3');


	},

	create:function(){
		game.state.start("menuGame");
	}
}

menuGame = {
	create:function(){

		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    	game.scale.forcePortrait = true;
    	game.scale.forceLandscape = false;
    	game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();
		
		home = game.add.image(0,0,'home');
		home.scale.set(1.4);
		pbtn = game.add.button(w/2,425,"play",this.lundag);
		pbtn.anchor.set(0.5);
    	pbtn.scale.x = 1.4;
    	pbtn.scale.y = 1.4;

    	abtn = game.add.button(w/2,530,"AboutBtn",this.aboutp);
		abtn.anchor.set(0.5);
    	abtn.scale.x = 1.4;
    	abtn.scale.y = 1.4;

		console.log("current state: menu");

	},
	update:function(){
			if(keyboard.up.isDown){
				
			}
	},
	lundag:function (){
		game.state.start("playGame");
   },
   aboutp:function (){
		about = game.add.image(0,0,'about');
		about.scale.x = 1;
		about.scale.y = 1;

		prevbtn = game.add.button(40,40,"PrevBtn",prevf);
		prevbtn.anchor.set(0.5);
    	prevbtn.scale.x = 0.3;
    	prevbtn.scale.y = 0.3;

    	function prevf() {
        	prevbtn.visible =! prevbtn.visible;
        	prevbtn.destroy();


       		 window.location.href=window.location.href;
            }
   },
  
}

playGame = {

	create: function(){
		console.log("current state: play");
		game.physics.startSystem(Phaser.Physics.ARCADE);
    game.add.sprite(0,0,'bg');
    tali1 = game.add.sprite(495,397,'tali1');
    game.physics.arcade.enable(tali1);
    tali1.body.immovable = true;
    tali1.scale.setTo(0.1,0.2);
    tali1.angle = 20;
    tao1 = game.add.sprite(440,h/2,'tao1');
    tao1.scale.setTo(0.4,0.4);
    player = game.add.sprite(50,500,'ako');
    
    tali = game.add.sprite(440,h/2,'img');
    tali.scale.setTo(0.4,0.4);

    kansyon =game.add.audio("kansyon",1,true);
        kansyon.Loop =true;
        kansyon.play();

    
    coin = game.add.sprite(550,500,'coin');
    game.physics.arcade.enable(coin);
    coin.body.immovable = true;
    coin.scale.setTo(0.4,0.4);
    platform = game.add.sprite(0,580,'platform');
    game.physics.arcade.enable(platform);
    platform.enableBody = true;
    platform.body.immovable = true;
    platform.scale.setTo(2.0,1.0);

    resetform = game.add.sprite(600,570,'platform');
    game.physics.arcade.enable(resetform);
    resetform.enableBody = true;
    resetform.body.immovable = true;
    resetform.scale.setTo(0.8,1.0);
    player.scale.setTo(1.4,1.4);
    scoreText = game.add.text(16, 16, 'score: 0', {fontSize: '32px' , fill: '#FFFFFF' } );
    highscoreText = game.add.text(16, 45, 'High Score: '+this.getScore(), {fontSize: '32px' , fill: '#FFFFFF' } );
    gameOverText = game.add.text(w/2-80, h/2-50,"",{fill:"red"});
    player.animations.add('walk-right',[0,1,2,3,4,5,6],20,true);
    keyboard = game.input.keyboard.createCursorKeys();
	

    game.physics.arcade.enable(player);
    player.body.collideWorldBounds = true;
    player.body.gravity.y = 3000;

    this.pauseButton = this.game.add.sprite(745, 25, 'pauseButton');
	this.pauseButton.inputEnabled = true;
	this.pauseButton.scale.x = 1.5;
	this.pauseButton.scale.y = 1.5;
	this.pauseButton.events.onInputUp.add(function () {this.game.paused = true;},this);
	this.game.input.onDown.add(function () {if(this.game.paused)this.game.paused = false;},this);
	upbtn = game.add.button(200,510,"JumpButton",this.lundag);
	leftbtn = game.add.button(10,510,"LeftButton",this.kawigi);
	rightbtn = game.add.button(470,510,"RightButton",this.kawanan);

	},

	update: function(){
		game.physics.arcade.enableBody(player,coin);
	game.physics.arcade.overlap(player,coin,this.ResetGame);
	game.physics.arcade.collide(player,platform);
	game.physics.arcade.overlap(player,resetform,this.ResetPlayer);
	game.physics.arcade.overlap(player,tali1,this.ResetGame);
	// if(keyboard.right.isDown){
	// 	player.body.velocity.x = 500;
	// 	player.animations.play('walk-right');
	// }
	// else if (keyboard.up.isDown){
	// 	if(player.body.touching.down){
	// 	player.body.velocity.y = -1000;
	// }	
	// }
	// else if(keyboard.down.isDown){
	// 	player.body.velocity.y = 500;
	// }
	// else{
	// 	player.body.velocity.x = 0;
	// 	player.animations.stop();
	// }

	// if(keyboard.up.isDown && player.body.touching.down){
	// 	console.log("x");
	// 	player.body.velocity.y = -1200; 
	// }

	// if(player.body.touching.down){
	// 	console.log("x");
	// }

	},
		// function killcoin(player,coin){
	killcoin:function (player,coin){
	player.reset(50,500);
	game.add.sprite(0,0,'sky');
	this.Over = game.add.text(400,270, '0', {font: '30px Arial', fill: '#ffffff'});
	this.Over.text = 'Game Over';
	this.Over.anchor.set(0.5);
	this.Over.scale.set(1.2);
	stateText = game.add.text(400,300,'',{font:'18px Times New Roman',fill:'white'});
	stateText.anchor.setTo(0.5,0.5);
	stateText.scale.set(1.3);
	stateText.visible = false;
    stateText.text="Double Tap to Restart";
	stateText.visible = true;
	game.input.onTap.addOnce(this.restart,this);
	game._paused = true

},

      
	saveScore:function (highscore) {
		localStorage.setItem("gamedata.com",score);
},
	getScore:function () {
		return (localStorage.getItem("gamedata.com") ==null || localStorage.getItem("gamedata.com") == "")?0:
		localStorage.getItem("gamedata.com");
	},
	lundag:function (){
	// if (game.physics.arcade.collide(player,platform)){
		
	// }
	player.body.velocity.y = -1200;
	},
		
 kawigi:function (){
	
			player.body.velocity.x = -500;
		player.animations.play('walk-left');
		
  

 },
 kawanan:function (){
	
			player.body.velocity.x = 500;
		player.animations.play('walk-right');
		
   
 },
 ResetPlayer:function (){
 	player.reset(50,500);
	score += 5;
	scoreText.text = 'Score:' + score;
	
		highscoreText.text='HighScore: '+score;
	
 	
 },
 loopAudio:function(time){
    setInterval(function(){
        kansyon.play();
    },time)
},
 ResetGame:function (){
 	player.reset(50,500);
 	game.add.sprite(0,0,'sky');
 	this.Over = game.add.text(400,270, '0', {font: '30px Arial', fill: '#ffffff'});
	this.Over.text = 'Game Over';
	this.Over.anchor.set(0.5);
	this.Over.scale.set(1.2);
	stateText = game.add.text(400,300,'',{font:'18px Times New Roman',fill:'white'});
	stateText.anchor.setTo(0.5,0.5);
	stateText.scale.set(1.3);
	stateText.visible = false;
    stateText.text="Double Tap to Restart";
	stateText.visible = true;
	restartButton=game.add.button(400,450,"restart",restartB,this);
    restartButton.scale.set(0.6);
    restartButton.anchor.set(0.5);
        function restartB() {
        //gamepage.visible =! restartButton.visible;
        //restartButton.destroy();

        window.location.href=window.location.href;
            }
	//game.input.onTap.addOnce(this.restart,this);
	game._paused = true	
 },
 restart:function (){
	window.location.href=window.location.href;
	stateText.visible = false;
},
		


};		

winGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}

loseGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}
